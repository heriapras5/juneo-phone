<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>



<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php
$periodLabels = ['daily' => 'Harian', 'weekly' => 'Mingguan', 'monthly' => 'Bulanan', 'yearly' => 'Tahunan'];
$periodIcons = ['daily' => 'fa-calendar-day', 'weekly' => 'fa-calendar-week', 'monthly' => 'fa-calendar-alt', 'yearly' => 'fa-calendar'];
$hasCustomRange = request()->has('from') && request()->has('to');
?>

<div class="space-y-6" id="dashboard-app">

    
    <div x-data="{ df: '<?php echo e($fromDate->format('Y-m-d')); ?>', dt: '<?php echo e($toDate->format('Y-m-d')); ?>' }" id="dashFilterBar" class="bg-white border border-gray-200 rounded-xl shadow-sm px-4 py-3 flex flex-wrap items-center gap-2">
        <span class="text-[11px] text-gray-500 font-medium mr-1 flex items-center gap-1.5">
            <i class="fas fa-filter text-yellow-500"></i> Filter waktu:
        </span>
        <?php $__currentLoopData = ['daily', 'weekly', 'monthly', 'yearly']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button data-period="<?php echo e($p); ?>"
            class="period-btn px-3.5 py-2 text-sm font-medium rounded-lg transition-colors <?php echo e($period === $p && !$hasCustomRange ? 'bg-gradient-to-r from-yellow-500 to-amber-500 text-white shadow-sm' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 shadow-sm'); ?>">
            <i class="fas <?php echo e($periodIcons[$p]); ?> mr-1.5"></i><?php echo e($periodLabels[$p]); ?>

        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <span class="hidden sm:inline text-gray-200">|</span>

        <div class="flex flex-wrap items-center gap-2">
            <span class="text-[11px] text-gray-500 font-medium">Dari</span>
            <input type="date" id="filterFrom" x-model="df"
                class="px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-yellow-500/30 focus:border-yellow-500 text-gray-900 outline-none">
            <span class="text-[11px] text-gray-500 font-medium">Sampai</span>
            <input type="date" id="filterTo" x-model="dt"
                class="px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-yellow-500/30 focus:border-yellow-500 text-gray-900 outline-none">
            <button id="applyDateBtn"
                class="px-4 py-2 text-sm font-medium bg-gradient-to-r from-yellow-500 to-amber-500 hover:from-yellow-400 hover:to-amber-400 text-white rounded-lg shadow-sm flex items-center gap-2">
                <i class="fas fa-check"></i> Terapkan
            </button>
            <button id="resetDateBtn"
                class="px-4 py-2 text-sm font-medium bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg shadow-sm flex items-center gap-2">
                <i class="fas fa-undo"></i> Reset
            </button>
        </div>
    </div>

    
    <div class="bg-white border border-gray-200 rounded-xl shadow-sm px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-3">
        <div class="flex items-center gap-3 text-sm text-gray-700">
            <span class="flex items-center justify-center w-9 h-9 rounded-lg bg-yellow-50 text-yellow-500">
                <i class="fas fa-calendar-alt"></i>
            </span>
            <div class="leading-tight">
                <span class="font-semibold" id="infoFromDate"><?php echo e($fromDate->format('d M Y')); ?></span>
                <span class="text-gray-300 mx-1">—</span>
                <span class="font-semibold" id="infoToDate"><?php echo e($toDate->format('d M Y')); ?></span>
                <div class="text-[11px] text-gray-400 mt-0.5" id="infoPeriodLabel"><?php echo e($hasCustomRange ? 'Rentang Kustom' : $periodLabels[$period]); ?></div>
            </div>
            <span class="hidden sm:inline text-[10px] text-gray-400 italic ml-1 max-w-[200px] leading-tight">Gunakan filter di atas untuk mengubah rentang waktu tampilan data</span>
        </div>
        <div class="flex flex-wrap items-center gap-2">
            <span id="infoBadge"
                class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium <?php echo e($isPeriodComplete ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'); ?>">
                <i class="fas <?php echo e($isPeriodComplete ? 'fa-check-circle' : 'fa-hourglass-half'); ?>"></i>
                <?php echo e($isPeriodComplete ? 'Selesai' : 'Belum Selesai'); ?>

            </span>
        </div>
        <div id="infoEndDate" class="sm:ml-auto text-xs text-gray-400 flex items-center gap-1.5" <?php if($isPeriodComplete): ?>style="display:none"<?php endif; ?>>
            <i class="fas fa-flag-checkered text-gray-300"></i>
            Berakhir <span id="infoEndDateText"><?php echo e($toDate->format('d M Y')); ?></span>
        </div>
    </div>

    
    <div id="biayaNotifWrap">
        <?php if(!$biayaCount): ?>
        <div class="bg-orange-50 border border-orange-200 text-orange-700 px-4 py-3 rounded-xl flex items-center gap-3 shadow-sm">
            <i class="fas fa-clock text-orange-500 text-lg"></i>
            <div class="flex-1">
                Kebutuhan Pribadi hari ini <strong>belum tercatat</strong>
            </div>
            <a href="<?php echo e(route('biaya-harian.index')); ?>" class="px-4 py-1.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-sm font-medium">
                Catat Sekarang
            </a>
        </div>
        <?php endif; ?>
    </div>

    
    <div id="emptyStateWrap"></div>

    
    <svg width="0" height="0" style="position:absolute;pointer-events:none">
        <defs>
            <linearGradient id="sparkAmber" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#F59E0B"/>
                <stop offset="100%" stop-color="#D97706"/>
            </linearGradient>
            <linearGradient id="sparkEmerald" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#10B981"/>
                <stop offset="100%" stop-color="#059669"/>
            </linearGradient>
        </defs>
    </svg>

    
    
    <section class="space-y-3" id="kpiSection">
        <div class="flex items-center gap-2">
            <span class="h-5 w-1.5 rounded-full bg-gradient-to-b from-yellow-500 to-amber-500"></span>
            <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wide">Ringkasan Keuangan</h2>
            <span class="text-[11px] text-gray-400 italic hidden sm:inline">— Pengeluaran, Omzet, Kebutuhan Pribadi &amp; Profit</span>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 items-stretch" id="rowKpi">
            <?php echo $__env->make('dashboard._partials.kpi-cards', [
                'periodLabels' => $periodLabels,
                'period' => $period,
                'fromDate' => $fromDate,
                'toDate' => $toDate,
                'periodTotals' => $periodTotals,
                'prevPeriodTotals' => $prevPeriodTotals,
                'changePengeluaran' => $changePengeluaran,
                'changeOmzet' => $changeOmzet,
                'changeKebutuhan' => $changeKebutuhan,
                'changeProfit' => $changeProfit,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>

    
    <section class="space-y-3" id="chartSection">
        <div class="flex items-center gap-2">
            <span class="h-5 w-1.5 rounded-full bg-gradient-to-b from-yellow-500 to-amber-500"></span>
            <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wide">Grafik &amp; Status</h2>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 bg-white border border-gray-200 rounded-xl shadow-sm p-5 transition-all duration-200 ease-in-out hover:-translate-y-1 hover:shadow-lg">
                <h3 class="text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                    <i class="fas fa-chart-bar text-yellow-500"></i>
                    Grafik <span id="chartPeriodLabel"><?php echo e($periodLabels[$period]); ?></span>
                </h3>
                <p class="text-[10px] text-gray-400 italic mb-3">Perbandingan Omzet, Pengeluaran &amp; Profit per periode</p>
                <div class="relative" style="height: 260px;">
                    <canvas id="revenueChart" style="max-height:100%;max-width:100%;"></canvas>
                </div>
            </div>
            <div class="bg-white border border-gray-200 rounded-xl shadow-sm p-5 transition-all duration-200 ease-in-out hover:-translate-y-1 hover:shadow-lg">
                <h3 class="text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                    <i class="fas fa-chart-donut text-yellow-500"></i>
                    Status Service
                </h3>
                <p class="text-[10px] text-gray-400 italic mb-3">Persentase status pengerjaan service saat ini</p>
                <div class="relative" style="height: 260px;">
                    <canvas id="statusChart" style="max-height:100%;max-width:100%;"></canvas>
                </div>
            </div>
        </div>
    </section>

    
    <section class="space-y-3">
        <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-2">
                <span class="h-5 w-1.5 rounded-full bg-gradient-to-b from-yellow-500 to-amber-500"></span>
                <h2 class="text-sm font-bold text-gray-800 uppercase tracking-wide">Service Terbaru</h2>
            </div>
            <a href="<?php echo e(route('services.index')); ?>" class="text-xs text-yellow-600 hover:text-yellow-700 font-medium">Lihat Semua →</a>
        </div>
        <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
            <p class="px-5 pt-3 text-[10px] text-gray-400 italic">10 service terakhir yang dicatat</p>
            <div class="divide-y divide-gray-100" id="recentServicesList">
                <?php $__empty_1 = true; $__currentLoopData = $recentServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="px-5 py-3 flex items-center justify-between hover:bg-gray-50/50">
                    <div class="flex items-center gap-3 min-w-0">
                        <div class="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-50 to-amber-100 flex items-center justify-center flex-shrink-0">
                            <i class="fas fa-mobile-alt text-yellow-600 text-xs"></i>
                        </div>
                        <div class="min-w-0">
                            <p class="text-sm font-medium text-gray-900 truncate"><?php echo e($service->customer?->nama ?? '-'); ?></p>
                            <?php $kr = is_string($service->kerusakan) ? json_decode($service->kerusakan, true) : $service->kerusakan; ?>
                            <p class="text-xs text-gray-500 truncate"><?php echo e($service->type_hp); ?> — <?php echo e(is_array($kr) ? implode(', ', $kr) : $service->kerusakan); ?></p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2 flex-shrink-0">
                        <?php
                        $cls = match($service->status) { 'menunggu' => 'bg-yellow-100 text-yellow-700', 'dikerjakan' => 'bg-blue-100 text-blue-700', 'selesai' => 'bg-emerald-100 text-emerald-700', 'diambil' => 'bg-gray-100 text-gray-600', 'batal' => 'bg-red-100 text-red-700', default => 'bg-gray-100 text-gray-600' };
                        $label = match($service->status) { 'menunggu' => 'Menunggu', 'dikerjakan' => 'Dikerjakan', 'selesai' => 'Selesai', 'diambil' => 'Diambil', 'batal' => 'Batal', default => $service->status };
                        ?>
                        <span class="inline-flex items-center justify-center px-3 py-1 rounded-full text-xs font-medium min-w-[90px] leading-none <?php echo e($cls); ?>"><?php echo e($label); ?></span>
                        <span class="text-xs text-gray-400 w-10 text-right"><?php echo e($service->tanggal->format('d/m')); ?></span>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-5 py-8 text-center text-gray-400">
                    <i class="fas fa-inbox text-2xl mb-1 block"></i>
                    Belum ada service
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
var periodLabels = <?php echo json_encode($periodLabels, 15, 512) ?>;
var statusCounts = <?php echo json_encode($statusCounts, 15, 512) ?>;
var chartInstance = null;
var statusChartInstance = null;
var lastUserAction = Date.now();
var refreshParams = {};
var dateFilterApi = {
    df: '<?php echo e($fromDate->format('Y-m-d')); ?>',
    dt: '<?php echo e($toDate->format('Y-m-d')); ?>',
    set: function(from, to) {
        this.df = from; this.dt = to;
        var el = document.getElementById('dashFilterBar');
        if (el) { try { Alpine.$data(el).df = from; Alpine.$data(el).dt = to; } catch(e) {} }
    }
};

function fmtRp(val) {
    return 'Rp ' + Number(val).toLocaleString('id-ID');
}

function fmtPct(val) {
    return (val >= 0 ? '+' : '') + Number(val).toFixed(1) + '%';
}

function updateTabActive(period, hasCustom) {
    document.querySelectorAll('.period-btn').forEach(function(btn) {
        var p = btn.dataset.period;
        if (p === period && !hasCustom) {
            btn.className = 'period-btn px-3.5 py-2 text-sm font-medium rounded-lg transition-colors bg-gradient-to-r from-yellow-500 to-amber-500 text-white shadow-sm';
        } else {
            btn.className = 'period-btn px-3.5 py-2 text-sm font-medium rounded-lg transition-colors bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 shadow-sm';
        }
    });
}

function updateChart(newChartData) {
    if (chartInstance) {
        chartInstance.data.labels = newChartData.labels;
        chartInstance.data.datasets[0].data = newChartData.omzet;
        chartInstance.data.datasets[1].data = newChartData.pengeluaran;
        chartInstance.resize();
        chartInstance.update();
    }
}

function updateStatusChart(newCounts) {
    if (!statusChartInstance) return;
    var counts = newCounts || statusCounts;
    if (typeof counts === 'undefined') return;
    var labels = ['Menunggu', 'Dikerjakan', 'Selesai', 'Diambil'];
    var data = [counts.menunggu || 0, counts.dikerjakan || 0, counts.selesai || 0, counts.diambil || 0];
    var colors = ['#F59E0B', '#3B82F6', '#10B981', '#6B7280'];
    if (counts.batal) { labels.push('Batal'); data.push(counts.batal); colors.push('#EF4444'); }
    statusChartInstance.data.labels = labels;
    statusChartInstance.data.datasets[0].data = data;
    statusChartInstance.update('none');
}

function updateRecentServices(services) {
    var wrap = document.getElementById('recentServicesList');
    if (!wrap || !services || services.length === 0) {
        if (wrap) wrap.innerHTML = '<div class="px-5 py-8 text-center text-gray-400"><i class="fas fa-inbox text-2xl mb-1 block"></i>Belum ada service</div>';
        return;
    }
    var statusMap = {
        'menunggu': { cls: 'bg-yellow-100 text-yellow-700', label: 'Menunggu' },
        'dikerjakan': { cls: 'bg-blue-100 text-blue-700', label: 'Dikerjakan' },
        'selesai': { cls: 'bg-emerald-100 text-emerald-700', label: 'Selesai' },
        'diambil': { cls: 'bg-gray-100 text-gray-600', label: 'Diambil' },
        'batal': { cls: 'bg-red-100 text-red-700', label: 'Batal' }
    };
    var html = '';
    services.forEach(function(s) {
        var st = statusMap[s.status] || { cls: 'bg-gray-100 text-gray-600', label: s.status };
        var kerusakan = Array.isArray(s.kerusakan) ? s.kerusakan.join(', ') : (s.kerusakan || '-');
        html += '<div class="px-5 py-3 flex items-center justify-between hover:bg-gray-50/50">'
            + '<div class="flex items-center gap-3 min-w-0">'
            +   '<div class="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-50 to-amber-100 flex items-center justify-center flex-shrink-0"><i class="fas fa-mobile-alt text-yellow-600 text-xs"></i></div>'
            +   '<div class="min-w-0">'
            +     '<p class="text-sm font-medium text-gray-900 truncate">' + s.customer_name + '</p>'
            +     '<p class="text-xs text-gray-500 truncate">' + s.type_hp + ' — ' + kerusakan + '</p>'
            +   '</div>'
            + '</div>'
            + '<div class="flex items-center gap-2 flex-shrink-0">'
            +   '<span class="inline-flex items-center justify-center px-3 py-1 rounded-full text-xs font-medium min-w-[90px] leading-none ' + st.cls + '">' + st.label + '</span>'
            +   '<span class="text-xs text-gray-400 w-10 text-right">' + s.tanggal + '</span>'
            + '</div></div>';
    });
    wrap.innerHTML = html;
}


function kpiCardHTML(cfg) {
    var changeHtml;
    if (cfg.change !== null && cfg.change !== undefined) {
        var up = cfg.change >= 0;
        var good = cfg.upIsGood ? up : !up;       
        var color = good ? 'emerald' : 'red';
        changeHtml = '<div class="flex items-center gap-1 mt-1">'
            + '<i class="fas fa-' + (up ? 'arrow-up' : 'arrow-down') + ' text-' + color + '-500 text-xs"></i>'
            + '<span class="text-xs font-medium text-' + color + '-600">' + fmtPct(cfg.change) + '</span>'
            + '<span class="text-xs text-gray-400">vs periode lalu</span>'
            + '</div>';
    } else {
        changeHtml = '<div class="flex items-center gap-1 mt-1"><span class="text-xs font-medium text-gray-400">— vs periode lalu</span></div>';
    }

    var foot  = cfg.foot  ? '<p class="text-xs text-gray-400 mt-1">' + cfg.foot + '</p>' : '';
    var extra = cfg.extra || '';

    return ''
    + '<div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden group flex flex-col h-full transition-all duration-200 ease-in-out hover:-translate-y-1 hover:shadow-lg">'
    +   '<div class="p-5 flex-1">'
    +     '<div class="flex items-start justify-between">'
    +       '<div class="flex-1 min-w-0">'
    +         '<p class="text-xs text-gray-500 uppercase tracking-wider font-medium">' + cfg.title + '</p>'
    +         '<p class="text-[10px] text-gray-400 italic mt-1">' + cfg.desc + '</p>'
    +         '<p class="text-2xl font-bold mt-1 ' + cfg.valueCls + '">' + fmtRp(cfg.value) + '</p>'
    +         extra
    +         foot
    +         changeHtml
    +       '</div>'
    +       '<div class="w-11 h-11 rounded-xl bg-gradient-to-br ' + cfg.iconBg + ' flex items-center justify-center shadow-md flex-shrink-0">'
    +         '<i class="fas ' + cfg.icon + ' text-' + cfg.iconColor + ' text-lg"></i>'
    +       '</div>'
    +     '</div>'
    +     '<div class="mt-3">'
    +       '<svg class="w-full h-8" viewBox="0 0 200 30" preserveAspectRatio="none">'
    +         '<path d="' + cfg.sparkPath + '" fill="none" stroke="' + cfg.sparkStroke + '" stroke-width="2" stroke-linecap="round"/>'
    +         '<path d="' + cfg.sparkPath + ' L200,30 L0,30 Z" fill="' + cfg.sparkFill + '" opacity="0.15"/>'
    +       '</svg>'
    +     '</div>'
    +   '</div>'
    +   '<div class="h-1 ' + cfg.barCls + '"></div>'
    + '</div>';
}

function buildKpiCardsHTML(d, periodLabel) {
    var profitPositive = d.profit >= 0;
    var cards = [
        kpiCardHTML({
            title: 'Pengeluaran ' + periodLabel,
            desc: 'Modal sparepart — total biaya beli komponen service',
            value: d.pengeluaran, valueCls: 'text-red-500',
            icon: 'fa-cart-shopping', iconBg: 'from-red-50 to-rose-100', iconColor: 'red-600',
            change: d.changePengeluaran, upIsGood: false,
            foot: d.services + ' service tercatat',
            sparkPath: 'M0,25 Q20,20 40,22 T80,15 T120,18 T160,8 T200,10',
            sparkStroke: '#EF4444', sparkFill: 'url(#sparkAmber)',
            barCls: 'bg-red-500'
        }),
        kpiCardHTML({
            title: 'Omzet ' + periodLabel,
            desc: 'Total tagihan jasa service ke pelanggan — belum dipotong biaya apapun',
            value: d.omzet, valueCls: 'text-gray-900',
            icon: 'fa-money-bill-wave', iconBg: 'from-emerald-50 to-green-100', iconColor: 'emerald-600',
            change: d.changeOmzet, upIsGood: true,
            foot: d.services + ' service tercatat',
            sparkPath: 'M0,25 Q25,15 45,20 T85,10 T125,14 T165,6 T200,12',
            sparkStroke: '#10B981', sparkFill: 'url(#sparkEmerald)',
            barCls: 'bg-emerald-500'
        }),
        kpiCardHTML({
            title: 'Kebutuhan Pribadi ' + periodLabel,
            desc: 'Bank Jago + Gaji Edi + Gaji Nur + Lainnya — total biaya kebutuhan harian',
            value: d.kebutuhan_pribadi, valueCls: 'text-orange-600',
            icon: 'fa-wallet', iconBg: 'from-orange-50 to-amber-100', iconColor: 'orange-600',
            change: d.changeKebutuhan, upIsGood: false,
            extra: '<div class="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs">'
                + '<span class="text-gray-400">Bank Jago:</span><span class="font-medium text-blue-600">' + fmtRp(d.bank_jago) + '</span>'
                + '<span class="text-gray-300">|</span>'
                + '<span class="text-gray-400">Gaji Edi:</span><span class="font-medium text-purple-600">' + fmtRp(d.gaji_edi) + '</span>'
                + '<span class="text-gray-300">|</span>'
                + '<span class="text-gray-400">Gaji Nur:</span><span class="font-medium text-purple-600">' + fmtRp(d.gaji_nur) + '</span>'
                + '<span class="text-gray-300">|</span>'
                + '<span class="text-gray-400">Lainnya:</span><span class="font-medium text-amber-600">' + fmtRp(d.lainnya) + '</span>'
                + '</div>',
            sparkPath: 'M0,25 Q20,20 40,22 T80,15 T120,18 T160,8 T200,10',
            sparkStroke: '#F59E0B', sparkFill: 'url(#sparkAmber)',
            barCls: 'bg-orange-500'
        }),
        kpiCardHTML({
            title: 'Profit ' + periodLabel,
            desc: 'Sisa keuntungan setelah dikurangi seluruh Kebutuhan Pribadi',
            value: d.profit, valueCls: profitPositive ? 'text-emerald-600' : 'text-red-600',
            icon: 'fa-coins', iconBg: 'from-emerald-50 to-green-100', iconColor: 'emerald-600',
            change: d.changeProfit, upIsGood: true,
            foot: 'Omzet - Pengeluaran - Kebutuhan Pribadi',
            sparkPath: 'M0,22 Q30,18 50,20 T100,12 T140,16 T180,5 T200,8',
            sparkStroke: profitPositive ? '#10B981' : '#EF4444',
            sparkFill: profitPositive ? 'url(#sparkEmerald)' : 'url(#sparkAmber)',
            barCls: profitPositive ? 'bg-emerald-500' : 'bg-red-500'
        })
    ];
    return cards.join('');
}

function updateCards(d) {
    // Update refreshParams untuk auto-refresh
    if (d.hasCustomRange) {
        refreshParams = { from: d.fromDateInput, to: d.toDateInput };
    } else if (d.period) {
        refreshParams = { period: d.period };
    }

    // Tab highlight
    updateTabActive(d.period, d.hasCustomRange);

    var periodLabel = d.hasCustomRange ? 'Rentang Kustom' : (periodLabels[d.period] || '');

    // Info bar
    document.getElementById('infoFromDate').textContent = d.fromDate;
    document.getElementById('infoToDate').textContent = d.toDate;
    document.getElementById('chartPeriodLabel').textContent = periodLabel;
    document.getElementById('infoPeriodLabel').textContent = periodLabel;

    // Badge
    var badge = document.getElementById('infoBadge');
    var isComp = d.isComplete;
    badge.className = 'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ' + (isComp ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200');
    badge.innerHTML = '<i class="fas ' + (isComp ? 'fa-check-circle' : 'fa-hourglass-half') + '"></i> ' + (isComp ? 'Selesai' : 'Belum Selesai');

    var endDate = document.getElementById('infoEndDate');
    if (isComp) { endDate.style.display = 'none'; }
    else { endDate.style.display = ''; document.getElementById('infoEndDateText').textContent = d.toDate; }

    // Input date values — Alpine x-model akan sikronkan ke DOM
    dateFilterApi.set(d.fromDateInput, d.toDateInput);

    // Notif Kebutuhan Pribadi, empty state, KPI, chart
    updateKpiOnly(d, periodLabel);
}

function updateKpiOnly(d, periodLabel) {
    // Restore date inputs via Alpine x-model — tahan terhadap Chrome autofill
    if (d.fromDateInput && d.toDateInput) dateFilterApi.set(d.fromDateInput, d.toDateInput);
    if (!periodLabel) {
        periodLabel = d.hasCustomRange ? 'Rentang Kustom' : (periodLabels[d.period] || '');
    }

    // Notif Kebutuhan Pribadi
    var bw = document.getElementById('biayaNotifWrap');
    if (!d.biayaCount) {
        bw.innerHTML = '<div class="bg-orange-50 border border-orange-200 text-orange-700 px-4 py-3 rounded-xl flex items-center gap-3 shadow-sm">'
            + '<i class="fas fa-clock text-orange-500 text-lg"></i>'
            + '<div class="flex-1">Kebutuhan Pribadi hari ini <strong>belum tercatat</strong></div>'
            + '<a href="<?php echo e(route('biaya-harian.index')); ?>" class="px-4 py-1.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-sm font-medium">Catat Sekarang</a>'
            + '</div>';
    } else {
        bw.innerHTML = '';
    }

    // Empty state
    var ew = document.getElementById('emptyStateWrap');
    if (d.services === 0) {
        ew.innerHTML = '<div class="bg-amber-50 border border-amber-200 text-amber-700 px-4 py-3 rounded-xl flex items-center gap-3 shadow-sm">'
            + '<i class="fas fa-info-circle text-amber-500 text-lg"></i>'
            + '<div class="flex-1">Belum ada data service pada periode ini.'
            + '<span class="text-[11px] text-amber-600 block mt-0.5">Gunakan filter waktu atau pilih periode lain untuk melihat laporan.</span></div>'
            + '</div>';
    } else {
        ew.innerHTML = '';
    }

    // === 4 KPI Cards — Pengeluaran | Omzet | Kebutuhan Pribadi | Profit ===
    document.getElementById('rowKpi').innerHTML = buildKpiCardsHTML(d, periodLabel);

    // Grafik
    updateChart(d.chartData);
}

function fetchData(params) {
    lastUserAction = Date.now();
    var url = '/dashboard/data?' + new URLSearchParams(params).toString();
    return fetch(url).then(function(r) { return r.json(); });
}

document.addEventListener('DOMContentLoaded', function() {
    // Init charts
    var chartData = <?php echo json_encode($chartData, 15, 512) ?>;
    var ctx1 = document.getElementById('revenueChart');
    if (ctx1) {
        chartInstance = new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [
                    { label: 'Omzet', data: chartData.omzet, backgroundColor: 'rgba(16,185,129,0.7)', borderColor: '#10B981', borderWidth: 1, borderRadius: 4, barPercentage: 0.7, categoryPercentage: 0.75 },
                    { label: 'Pengeluaran', data: chartData.pengeluaran, backgroundColor: 'rgba(239,68,68,0.5)', borderColor: '#EF4444', borderWidth: 1, borderRadius: 4, barPercentage: 0.7, categoryPercentage: 0.75 },
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                layout: { padding: { top: 5, right: 10 } },
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, padding: 12, font: { size: 11 } } },
                    tooltip: { mode: 'index', intersect: false }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { callback: function(v) { return 'Rp ' + v.toLocaleString('id-ID'); }, font: { size: 10 } }, grid: { color: 'rgba(0,0,0,0.06)' } },
                    x: { grid: { display: false }, ticks: { maxRotation: 45, font: { size: 10 }, autoSkip: true, maxTicksLimit: 12 } }
                }
            }
        });
    }

    var ctx2 = document.getElementById('statusChart');
    if (ctx2) {
        var scLabels = ['Menunggu', 'Dikerjakan', 'Selesai', 'Diambil'];
        var scData = [statusCounts.menunggu || 0, statusCounts.dikerjakan || 0, statusCounts.selesai || 0, statusCounts.diambil || 0];
        var scColors = ['#F59E0B', '#3B82F6', '#10B981', '#6B7280'];
        if (statusCounts.batal) { scLabels.push('Batal'); scData.push(statusCounts.batal); scColors.push('#EF4444'); }
        statusChartInstance = new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: scLabels,
                datasets: [{ data: scData, backgroundColor: scColors, borderWidth: 0 }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                cutout: '70%',
                plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, padding: 10, font: { size: 11 } } } }
            }
        });
    }

    // Tab clicks
    document.querySelectorAll('.period-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            var p = this.dataset.period;
            fetchData({ period: p }).then(function(data) { updateCards(data); });
        });
    });

    // Apply date filter — baca dari Alpine data, bukan DOM (tahan terhadap Chrome autofill)
    document.getElementById('applyDateBtn').addEventListener('click', function() {
        var el = document.getElementById('dashFilterBar');
        var from, to;
        if (el) { try { var a = Alpine.$data(el); from = a.df; to = a.dt; } catch(e) {} }
        if (!from || !to) { from = document.getElementById('filterFrom').value; to = document.getElementById('filterTo').value; }
        if (!from || !to) { alert('Harap isi tanggal Dari dan Sampai terlebih dahulu.'); return; }
        if (from > to) { alert('Tanggal "Dari" tidak boleh lebih besar dari tanggal "Sampai".'); return; }
        dateFilterApi.set(from, to);
        fetchData({ from: from, to: to }).then(function(data) { updateCards(data); });
    });

    // Reset filter — reload halaman tanpa parameter (auto-detect period)
    document.getElementById('resetDateBtn').addEventListener('click', function() {
        window.location.href = '<?php echo e(route("dashboard")); ?>';
    });

    // Auto-refresh tiap 30 detik (gentle: lewati jika user baru saja berinteraksi)
    var currentParams = new URLSearchParams(window.location.search);
    if (currentParams.get('period')) refreshParams = { period: currentParams.get('period') };
    else if (currentParams.get('from') && currentParams.get('to')) { refreshParams = { from: currentParams.get('from'), to: currentParams.get('to') }; }
    else refreshParams = { period: '<?php echo e($period); ?>' };

    setInterval(function() {
        if (Date.now() - lastUserAction < 15000) return; 
        
        fetch('/dashboard/data?' + new URLSearchParams(refreshParams).toString())
            .then(function(r) { return r.json(); })
            .then(function(dashData) { updateKpiOnly(dashData); })
            .catch(function() {});
        fetch('/dashboard/recent-services')
            .then(function(r) { return r.json(); })
            .then(function(recentData) {
                updateRecentServices(recentData.recentServices);
                updateStatusChart(recentData.statusCounts);
            })
            .catch(function() {});
    }, 30000);

    window.addEventListener('resize', function() {
        if (chartInstance) chartInstance.resize();
        if (statusChartInstance) statusChartInstance.resize();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Dataku (H)\Projek Domosquere CPanel\juneo-phone\resources\views/dashboard/index.blade.php ENDPATH**/ ?>